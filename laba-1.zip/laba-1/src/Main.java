import java.util.Scanner;
import java.util.Date;
import java.text.SimpleDateFormat;

class Calculator {
    static double a = 0.1;
    static double b = -0.5;
    static double x = 1.65;

    static void calculateF1() {
        double result = Math.cos(Math.log(Math.abs(Math.random() * a))) - Math.pow(Math.log(Math.abs(b * x - a)), 2);
        System.out.println("f1(x) = " + result);
    }

    static void calculateF2() {
        double result = Math.pow(Math.sinh(Math.pow(Math.abs(a * Math.sqrt(Math.abs(Math.cos(b * x)))), 2)), 2);
        System.out.println("f2(x) = " + result);
    }

    static void printCurrentDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        Date currentDate = new Date();
        System.out.println("Поточна дата і час: " + dateFormat.format(currentDate));
    }

    static void inputData() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введіть значення параметра a: ");
        a = scanner.nextDouble();
        System.out.print("Введіть значення параметра b: ");
        b = scanner.nextDouble();
        System.out.print("Введіть значення параметра x: ");
        x = scanner.nextDouble();
    }

    static void outputData() {
        System.out.println("Введені вхідні дані:");
        System.out.println("a = " + a);
        System.out.println("b = " + b);
        System.out.println("x = " + x);
    }

    static void menu() {
        Scanner scanner = new Scanner(System.in);
        int choice;
        do {
            System.out.println("\nМеню:");
            System.out.println("1. Ввести вхідні дані");
            System.out.println("2. Вивести вхідні дані");
            System.out.println("3. Обчислити значення функцій");
            System.out.println("4. Вивести поточну дату і час");
            System.out.println("5. Вихід");
            System.out.print("Виберіть опцію: ");
            choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    inputData();
                    break;
                case 2:
                    outputData();
                    break;
                case 3:
                    calculateF1();
                    calculateF2();
                    break;
                case 4:
                    printCurrentDateTime();
                    break;
                case 5:
                    System.out.println("Програма завершує роботу.");
                    break;
                default:
                    System.out.println("Невірний вибір. Спробуйте ще раз.");
            }
        } while (choice != 5);
    }
}

public class Main {
    public static void main(String[] args) {
        Calculator.menu();
    }
}
